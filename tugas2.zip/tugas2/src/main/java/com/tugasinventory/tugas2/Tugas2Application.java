package com.tugasinventory.tugas2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tugas2Application {

	public static void main(String[] args) {
		SpringApplication.run(Tugas2Application.class, args);
	}

}
